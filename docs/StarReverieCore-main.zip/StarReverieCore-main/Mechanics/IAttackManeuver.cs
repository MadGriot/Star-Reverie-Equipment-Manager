﻿// -----------------------------------------------------------------------
// 	IAttackManeuver.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using StarReverieCore.Equipment;

namespace StarReverieCore.Mechanics
{
    public interface IAttackManeuver
    {
        DamageType DamageType { get; set; }
        Skill Skill { get; set; }
        public int DiceCount { get; set; }
        public int Modifier { get; set; }

    }
}
