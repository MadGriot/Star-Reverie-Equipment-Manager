﻿// -----------------------------------------------------------------------
//     Author: Trenton Scott
//     Copyright 2025 Centuras LLC. All rights reserved.
// -----------------------------------------------------------------------

namespace StarReverieCore.Equipment
{
    public enum WeaponClass
    {
        Pistol,
        Rifle,
        Spear,
        Sword,
        Fist,
        Staff,
        Shotgun
    }
}
