﻿// -----------------------------------------------------------------------
// 	Skill.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public enum Skill
    {
        Acrobatics,
        Armory,
        AstralTech,
        BallisticWeapons,
        ComputerKnowledge,
        EnergyWeapons,
        Engineering,
        FirstAid,
        HeavyWeapons,
        Leadership,
        Lockpicking,
        MartialArts,
        MeleeWeapons,
        Merchant,
        Piloting,
        Science,
        Throwing,
    }
}
