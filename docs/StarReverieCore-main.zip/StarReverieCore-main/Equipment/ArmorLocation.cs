﻿// -----------------------------------------------------------------------
//     Author: Trenton Scott
//     Copyright 2025 Centuras. All rights reserved.
// -----------------------------------------------------------------------

namespace StarReverieCore.Equipment
{
    public enum ArmorLocation
    {
        Head,
        Body,
        LeftArm,
        RightArm,
        LeftLeg,
        RightLeg,
        FullSuit,
    }
}
