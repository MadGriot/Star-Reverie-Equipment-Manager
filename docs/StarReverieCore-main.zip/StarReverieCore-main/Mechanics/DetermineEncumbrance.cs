﻿// -----------------------------------------------------------------------
// 	DetermineEncumbrance.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using StarReverieCore.Models;

namespace StarReverieCore.Mechanics
{

    public static class DetermineEncumbrance
    {
        public static Encumbrance CalculateWeight(Character character)
        {
            decimal weight = character.AttributeScore.Weight;
            int carryWeight = character.AttributeScore.BasicLift;

            return weight switch
            {
                <= 0 => Encumbrance.None,
                _ when weight < carryWeight => Encumbrance.None,
                _ when weight < 2 * carryWeight => Encumbrance.Light,
                _ when weight < 3 * carryWeight => Encumbrance.Medium,
                _ => Encumbrance.Heavy
            };

        }

        public static void AddWeightFromUnit(UnitStack? unitStack, Character character, int quantity)
        {
            switch (unitStack?.Unit)
            {
                case WeaponModel:
                    WeaponModel weapon = (WeaponModel)unitStack.Unit;
                    character.AttributeScore.Weight += weapon.WeaponWeight * quantity;
                    break;

                case ArmorModel:
                    ArmorModel armor = (ArmorModel)unitStack.Unit;
                    character.AttributeScore.Weight += armor.Weight * quantity;
                    break;

                case ShieldModel:
                    ShieldModel shield = (ShieldModel)unitStack.Unit;
                    character.AttributeScore.Weight += shield.Weight * quantity;
                    break;

                case AmmoModel:
                    AmmoModel ammo = (AmmoModel)unitStack.Unit;
                    character.AttributeScore.Weight += ammo.Weight * quantity;
                    break;
            }
        }
    }
}
