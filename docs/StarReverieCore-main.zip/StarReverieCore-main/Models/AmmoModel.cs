﻿// -----------------------------------------------------------------------
// 	AmmoModel.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class AmmoModel : Unit
    {
        public decimal Weight { get; set; }
        public decimal Cost { get; set; }
        public int WeaponModelId { get; set; }
        public List<WeaponModel> Weapons { get; set; } = new();
    }
}
