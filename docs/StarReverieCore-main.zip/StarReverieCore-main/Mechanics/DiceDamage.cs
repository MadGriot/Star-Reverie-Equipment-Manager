﻿// -----------------------------------------------------------------------
// 	DiceDamage.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public class DiceDamage
    {
        public int DiceCount { get; set; }
        public int Modifier { get; set; }

        public DiceDamage(IAttackManeuver attackManeuver)
        {
            DiceCount = attackManeuver.DiceCount;
            Modifier = attackManeuver.Modifier;
        }

        public int RollDamage()
        {
            int total = 0;
            for (int i = 0; i < DiceCount; i++)
                total += Roll._1d6();
            return total + Modifier;
        }

        public override string ToString()
        {
            string mod = Modifier switch
            {
                > 0 => $"+{Modifier}",
                < 0 => $"{Modifier}",
                _ => ""
            };
            return $"{DiceCount}d{mod}";
        }
    }
}
