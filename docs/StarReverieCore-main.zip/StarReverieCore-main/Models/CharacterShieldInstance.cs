﻿// -----------------------------------------------------------------------
// 	CharacterShieldInstance.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class CharacterShieldInstance
    {
        public int Id { get; set; }

        // link to character
        public int CharacterId { get; set; }
        public Character Character { get; set; } = null!;

        // link to base shield definition
        public int ShieldModelId { get; set; }
        public ShieldModel ShieldModel { get; set; } = null!;

        // per-character state
        public int CurrentSP { get; set; }   // current shield points or energy
        public bool IsEquipped { get; set; } // convenience flag
    }
}
