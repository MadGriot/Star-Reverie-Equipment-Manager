﻿// -----------------------------------------------------------------------
//     Author: Trenton Scott
//     Copyright 2025 Centuras LLC. All rights reserved.
// -----------------------------------------------------------------------

namespace StarReverieCore.Equipment
{
    public enum WeaponType
    {
        MeleePhysical,
        MeleeEnergy,
        RangedPhysical,
        RangedEnergy,
    }
}
