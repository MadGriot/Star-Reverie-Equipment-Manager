﻿// -----------------------------------------------------------------------
// 	InventoryModel.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class InventoryModel
    {
        public int Id { get; set; }

        public int CharacterId { get; set; }
        public Character Character { get; set; } = null!;

        public List<UnitStack> Units { get; set; } = new();
    }
}
