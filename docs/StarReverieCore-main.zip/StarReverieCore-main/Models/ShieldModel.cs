﻿// -----------------------------------------------------------------------
// 	ShieldModel.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class ShieldModel : Unit
    {
        public int MinSP { get; set; }
        public int MaxSP { get; set; }
        public int SPCost { get; set; }
        public int Cost { get; set; }
        public int Weight { get; set; }

    }
}
