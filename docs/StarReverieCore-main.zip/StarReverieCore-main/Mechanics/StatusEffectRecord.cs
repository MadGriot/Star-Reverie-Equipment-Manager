﻿// -----------------------------------------------------------------------
// 	StatusEffectRecord.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public record StatusEffectRecord
    {
        public StatusEffect StatusEffect { get; set; }
        public float StatusEffectStrength { get; set; }
        public int TurnDuration { get; set; }

        public StatusEffectRecord(StatusEffect statusEffect, float statusEffectStrength, int turnDuration)
        {
            StatusEffect = statusEffect;
            StatusEffectStrength = statusEffectStrength;
            TurnDuration = turnDuration;
        }
    }
}
