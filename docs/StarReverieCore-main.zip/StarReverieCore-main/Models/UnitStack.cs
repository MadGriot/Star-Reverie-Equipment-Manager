﻿// -----------------------------------------------------------------------
// 	UnitStack.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class UnitStack
    {
        public int Id { get; set; }

        public int UnitId { get; set; }
        public Unit? Unit { get; set; }

        public int InventoryId { get; set; }
        public InventoryModel Inventory { get; set; } = null;

        public int Quantity { get; set; }
    }
}
