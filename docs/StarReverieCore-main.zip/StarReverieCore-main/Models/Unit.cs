﻿// -----------------------------------------------------------------------
// 	Unit.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using StarReverieCore.Mechanics;

namespace StarReverieCore.Models
{
    public abstract class Unit
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public Skill Skill { get; set; }
        public int DiceCount { get; set; }
        public int Modifier { get; set; }
        public List<Character>? Characters { get; set; }
    }
}
