﻿// -----------------------------------------------------------------------
// 	StarReverDbContext.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using StarReverieCore.Models;

namespace StarReverieCore
{
    public class StarReverieDbContext : DbContext
    {
        public string DbPath { get; private set; }
        public StarReverieDbContext()
        {
            string basePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)!;

            string dbFolder = Path.Combine(basePath, "Database");

            if (!Directory.Exists(dbFolder))
                Directory.CreateDirectory(dbFolder);

            DbPath = Path.Combine(dbFolder, "StarReverie.db");
        }
        public DbSet<Character> Characters { get; set; }
        public DbSet<AttributeScore> AttributeScores { get; set; }
        public DbSet<DialogueModel> Dialogues { get; set; }
        public DbSet<SkillModel> Skills { get; set; }
        public DbSet<WeaponModel> Weapons { get; set; }
        public DbSet<CharacterWeaponInstance> CharacterWeaponInstances { get; set; }
        public DbSet<CharacterShieldInstance> CharacterShieldInstances { get; set; }
        public DbSet<ArmorModel> Armors { get; set; }
        public DbSet<ShieldModel> Shields { get; set; }
        public DbSet<AstralTech> AstralTechniques { get; set; }
        public DbSet<Technique> Techniques { get; set; }
        public DbSet<SquadModel> Squads { get; set; }
        public DbSet<AmmoModel> Ammos { get; set; }
        public DbSet<UnitStack> UnitStacks { get; set; }
        public DbSet<InventoryModel> Inventories { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Data Source={DbPath}")
                .LogTo(Console.WriteLine, LogLevel.Information)
                .EnableSensitiveDataLogging()
                .EnableDetailedErrors();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            modelBuilder.Entity<Unit>().UseTptMappingStrategy();
            modelBuilder.Entity<Character>()
                    .HasOne(c => c.AttributeScore)
                    .WithOne(a => a.Character)
                    .HasForeignKey<AttributeScore>(k => k.CharacterId);

            modelBuilder.Entity<Character>()
                .HasMany(c => c.Skills)
                .WithOne(a => a.Character)
                .HasForeignKey(s => s.CharacterId);

            modelBuilder.Entity<Character>()
                .HasOne(c => c.Weapon)
                .WithMany(a => a.Characters)
                .HasForeignKey(s => s.WeaponId);

            modelBuilder.Entity<Character>()
                .HasMany(c => c.AstralTech)
                .WithMany(a => a.Characters)
                .UsingEntity(j => j.ToTable("CharacterAstralTechniques"));

            modelBuilder.Entity<Character>()
                .HasMany(c => c.Techniques)
                .WithMany(a => a.Characters)
                .UsingEntity(j => j.ToTable("CharacterTechniques"));

            modelBuilder.Entity<Character>()
                .HasOne(c => c.Armor)
                .WithMany(a => a.Characters)
                .HasForeignKey(s => s.ArmorId);

            modelBuilder.Entity<Character>()
                .HasOne(c => c.Shield)
                .WithMany(a => a.Characters)
                .HasForeignKey(s => s.ShieldId);

            // Ammo (1) → Weapons (M)
            modelBuilder.Entity<WeaponModel>()
                .HasOne(w => w.Ammo)
                .WithMany(a => a.Weapons)
                .HasForeignKey(w => w.AmmoId);

            // Character → Inventory (1:1)
            modelBuilder.Entity<Character>()
                .HasOne(c => c.Inventory)
                .WithOne(i => i.Character)
                .HasForeignKey<InventoryModel>(i => i.CharacterId);

            // Inventory → UnitStacks (1:M)
            modelBuilder.Entity<InventoryModel>()
                .HasMany(i => i.Units)
                .WithOne(us => us.Inventory)
                .HasForeignKey(us => us.InventoryId);

            // UnitStack → Unit (M:1)
            modelBuilder.Entity<UnitStack>()
                .HasOne(us => us.Unit)
                .WithMany() // or .WithMany(u => u.UnitStacks) if Unit has that collection
                .HasForeignKey(us => us.UnitId);

            modelBuilder.Entity<CharacterWeaponInstance>()
                .HasOne(cwi => cwi.Character)
                .WithMany(c => c.WeaponInstances)
                .HasForeignKey(cwi => cwi.CharacterId);

            modelBuilder.Entity<CharacterWeaponInstance>()
                .HasOne(cwi => cwi.WeaponModel)
                .WithMany()
                .HasForeignKey(cwi => cwi.WeaponModelId);

            // --- Shield relationships ---
            modelBuilder.Entity<CharacterShieldInstance>()
                .HasOne(csi => csi.Character)
                .WithMany(c => c.ShieldInstances)
                .HasForeignKey(csi => csi.CharacterId);

            modelBuilder.Entity<CharacterShieldInstance>()
                .HasOne(csi => csi.ShieldModel)
                .WithMany()
                .HasForeignKey(csi => csi.ShieldModelId);
        }
    }
}
