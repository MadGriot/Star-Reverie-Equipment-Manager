﻿// -----------------------------------------------------------------------
// 	GridPosition.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------
namespace StarReverieCore.Grid
{
    public record struct GridPosition
    {
        public int x;
        public int y;
        public int z;

        public GridPosition(int x, int y, int z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        //public bool Equals(GridPosition other) => this == other;
        //public override int GetHashCode() => HashCode.Combine(x, y, z);

        public override string ToString() => $"x: {x}; y: {y}; z: {z}";

        public static GridPosition operator +(GridPosition a, GridPosition b) =>
            new GridPosition(a.x + b.x, a.y + b.y, a.z + b.z);

        public static GridPosition operator -(GridPosition a, GridPosition b) =>
            new GridPosition(a.x - b.x, a.y - b.y, a.z - b.z);
    }
}
