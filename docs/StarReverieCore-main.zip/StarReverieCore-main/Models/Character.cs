﻿// -----------------------------------------------------------------------
// 	Character.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class Character
    {
        public int Id { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public int Age { get; set; }
        public Species Species { get; set; }
        public Gender Gender { get; set; }
        public int Level { get; set; }
        public int PowerLevel { get; set; }
        public List<SkillModel> Skills { get; set; } = new();
        public AttributeScore AttributeScore { get; set; }
        public int AttributePoints { get; set; }
        public int SkillPoints { get; set; }
        public string PortraitPath { get; set; }

        // NEW: per-character weapon instances
        public List<CharacterWeaponInstance> WeaponInstances { get; set; } = new();
        // new shield system
        public List<CharacterShieldInstance> ShieldInstances { get; set; } = new();

        // Keep your old Weapon property for compatibility
        public int? WeaponId { get; set; }
        public WeaponModel? Weapon { get; set; }

        public List<AstralTech> AstralTech { get; set; } = new();
        public List<Technique> Techniques { get; set; } = new();
        public int? ArmorId { get; set; }
        public ArmorModel? Armor { get; set; }
        public int? ShieldId { get; set; }
        public ShieldModel? Shield { get; set; }
        public int? SquadId { get; set; }
        public SquadModel? Squad { get; set; }
        public InventoryModel? Inventory { get; set; } = new();
    }
}
