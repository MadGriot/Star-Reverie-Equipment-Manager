﻿// -----------------------------------------------------------------------
// 	WeaponModel.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using StarReverieCore.Equipment;
using StarReverieCore.Mechanics;

namespace StarReverieCore.Models
{
    public class WeaponModel : Unit, IAttackManeuver
    {
        public required WeaponType WeaponType { get; set; }
        public required DamageType DamageType { get; set; }
        public WeaponClass WeaponClass { get; set; }
        public int Accuracy { get; set; }
        public int Range { get; set; }
        public decimal WeaponWeight { get; set; }
        public decimal AmmoWeight { get; set; }
        public int RoF { get; set; }
        public int MaxAmmo { get; set; }
        public int CurrentAmmo { get; set; }
        public int STRRequirement { get; set; }
        public int Bulk { get; set; }
        public decimal Cost { get; set; }
        public string? WeaponSoundPath { get; set; }
        public int? AmmoId { get; set; }
        public AmmoModel? Ammo { get; set; }

    }
}
