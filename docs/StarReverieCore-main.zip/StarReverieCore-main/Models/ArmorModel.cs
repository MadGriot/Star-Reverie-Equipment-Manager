﻿// -----------------------------------------------------------------------
// 	ArmorModel.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------
using StarReverieCore.Equipment;

namespace StarReverieCore.Models
{
    public class ArmorModel : Unit
    {
        public required ArmorLocation ArmorLocation { get; set; }
        public int DamageResistance { get; set; }
        public int Cost { get; set; }
        public int Weight { get; set; }
    }
}
