﻿// -----------------------------------------------------------------------
// 	StatusEffect.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public enum StatusEffect
    {
        None,
        Poison,
        Stunned,
        Burned,
        Dark,
        Drenched,
        Light,
        Shocked,
        Petrification,
        Sleep,
        Firewalled,
        Frostbite,
        BurnEffect,
        DrenchEffect,
        ChillEffect,
        ShockEffect,
        Hit,
        DamageResistance
    }
}
