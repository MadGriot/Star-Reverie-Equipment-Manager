﻿// -----------------------------------------------------------------------
// 	Species.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public enum Species
    {
        Human,
        Sutharian,
        Karnok,
        Dragon,
        Plant,
    }
}
