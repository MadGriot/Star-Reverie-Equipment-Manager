﻿// -----------------------------------------------------------------------
// 	CharacterWeaponInstance.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public class CharacterWeaponInstance
    {
        public int Id { get; set; }

        // Link to character
        public int CharacterId { get; set; }
        public Character Character { get; set; } = null!;

        // Link to base weapon definition
        public int WeaponModelId { get; set; }
        public WeaponModel WeaponModel { get; set; } = null!;

        // Per-character state
        public int CurrentAmmo { get; set; }
        public bool IsEquipped { get; set; }
    }
}
