﻿// -----------------------------------------------------------------------
// 	SkillDifficulty.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public enum SkillDifficulty
    {
        Easy,
        Average,
        Hard,
        VeryHard
    }
}
