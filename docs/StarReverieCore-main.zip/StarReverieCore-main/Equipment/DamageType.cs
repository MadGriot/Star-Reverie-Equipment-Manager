﻿// -----------------------------------------------------------------------
//     Author: Trenton Scott
//     Copyright 2025 Centuras LLC. All rights reserved.
// -----------------------------------------------------------------------
namespace StarReverieCore.Equipment
{
    public enum DamageType
    {
        Affliction,
        Burning,
        Corrosion,
        Chilling,
        Crushing,
        Cutting,
        Drenching,
        Fatigue,
        Impaling,
        Piercing,
        Shocking,
        Toxic,
        Healing,
        Buff,
        Debuff,
        Gravity,
    }
}
