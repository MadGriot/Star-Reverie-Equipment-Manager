﻿// -----------------------------------------------------------------------
// 	Gender.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Models
{
    public enum Gender
    {
        Male,
        Female,
        NonBinary,
    }
}
