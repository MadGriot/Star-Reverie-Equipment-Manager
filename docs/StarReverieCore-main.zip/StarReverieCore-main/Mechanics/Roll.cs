﻿// -----------------------------------------------------------------------
// 	Roll.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public class Roll
    {
        private static Random rnd = new Random();

        public static int _3d6() => rnd.Next(1, 7) + rnd.Next(1, 7) + rnd.Next(1, 7);

        public static int _2d6() => rnd.Next(1, 7) + rnd.Next(1, 7);
          
        public static int _1d6() => rnd.Next(1, 7);

        public static int _3d4() => rnd.Next(1, 5) + rnd.Next(1, 5) + rnd.Next(1, 5);

        public static int _2d4() => rnd.Next(1, 5) + rnd.Next(1, 5);

        public static int _1d4() => rnd.Next(1, 5);
        
    }
}
