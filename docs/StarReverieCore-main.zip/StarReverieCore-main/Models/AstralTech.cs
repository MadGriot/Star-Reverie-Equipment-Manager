﻿// -----------------------------------------------------------------------
// 	AstralTech.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using StarReverieCore.Equipment;
using StarReverieCore.Mechanics;

namespace StarReverieCore.Models
{
    public class AstralTech : Unit, IAttackManeuver
    {
        public required DamageType DamageType { get; set; }
        public required AstralTechEffect Effect { get; set; }
        public required bool IsOffensive { get; set; }
        public StatusEffect StatusEffect { get; set; }
        public float StatusEffectStrength { get; set; }
        public int Accuracy { get; set; }
        public int Range { get; set; }
        public int TurnCount { get; set; }
        public int TurnCountMax { get; set; }
        public int TurnDuration { get; set; }
        public int StaminaCost { get; set; }
        public int IntelligenceRequirement { get; set; }
        public int Radius { get; set; }
        public int Cost { get; set; }
        public TargetArea TargetArea { get; set; }
    }
}
