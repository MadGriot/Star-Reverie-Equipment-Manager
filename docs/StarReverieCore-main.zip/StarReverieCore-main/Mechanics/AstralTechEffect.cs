﻿// -----------------------------------------------------------------------
// 	AstralTechEffect.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

namespace StarReverieCore.Mechanics
{
    public enum AstralTechEffect
    {
        None,
        Resistance,
        Status,
    }
}
