﻿// -----------------------------------------------------------------------
// 	Technique.cs
// 	Author: Trenton Scott 
// 	Copyright (c) Centuras. All rights reserved.
//  -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;

namespace StarReverieCore.Models
{
    public class Technique : Unit
    {
        public required bool IsOffensive { get; set; }
        public int TurnCount { get; set; }
        public int TurnCountMax { get; set; }
        public int StaminaCost { get; set; }
        public int Cost { get; set; }
    }
}
